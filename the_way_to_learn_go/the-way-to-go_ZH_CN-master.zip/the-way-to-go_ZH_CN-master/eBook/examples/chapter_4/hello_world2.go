package main

import "fmt" // Package implementing formatted I/O.

func main() {
	fmt.Printf("Hello, world; or Καλημέρα κόσμε; or こんにちは 世界\n")
}

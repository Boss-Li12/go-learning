// hello_world1.go
package main

func main() {
	println("Hello", "world")
}

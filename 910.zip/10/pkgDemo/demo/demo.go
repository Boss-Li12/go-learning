package demo //自定义包名

import (
	"fmt"
)

func PrintStr() {
	fmt.Println("Hello world!")
}

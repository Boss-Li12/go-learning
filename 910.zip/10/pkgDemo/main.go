package main

import "pkgDemo/demo"

func main() {
	demo.PrintStr()
}

package main //定义当前代码所属的包，main是特殊包名，表示当前是一个可执行程序，不是库

import "fmt" //导入标准库的fmt（format）包

func main() { //程序执行入口

	fmt.Print("hello, world") //默认不需要; 加;也没错
}

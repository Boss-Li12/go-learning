package main

import "fmt"

//Hello 函数用来被测试
func Hello() string {
	return "Hello, world"
}

func main() {
	fmt.Println(Hello())
}
